from django.apps import AppConfig


class DjangoBox(AppConfig):
    name = 'django_box'
