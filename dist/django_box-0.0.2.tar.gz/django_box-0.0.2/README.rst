Django Box
====


# SETTINGS

BOX_MODULE_PATH
path where the module reside

BOX_TEMPLATE_PATH
path where the template reside