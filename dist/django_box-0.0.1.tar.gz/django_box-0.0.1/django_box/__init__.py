def box():
    print("Box")
